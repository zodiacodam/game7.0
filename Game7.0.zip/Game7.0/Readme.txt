Bottom Navigation Bar in Android Studio through a simple demo application

Link to youtube tutorial : https://www.youtube.com/watch?v=2LtObBTF9CM 
Link to youtube channel  : https://www.youtube.com/channel/UCLIFAN-83cSg5EsKJApAscQ
