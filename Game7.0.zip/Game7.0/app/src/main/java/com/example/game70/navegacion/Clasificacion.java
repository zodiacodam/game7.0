package com.example.game70.navegacion;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.game70.hilo.HiloClasificacion;
import com.example.game70.R;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class Clasificacion extends Fragment {

    public static TextView pos0, victorias0, equipo0, puntos0, pos1, victorias1, equipo1, puntos1, pos2, victorias2, equipo2, puntos2, pos3, victorias3, equipo3, puntos3,
            pos4, victorias4, equipo4, puntos4, pos5, victorias5, equipo5, puntos5, pos6, victorias6, equipo6, puntos6, pos7, victorias7, equipo7, puntos7, pos8, victorias8, equipo8, puntos8,
            pos9, victorias9, equipo9, puntos9, pos10, victorias10, equipo10, puntos10, pos11, victorias11, equipo11, puntos11, pos12, victorias12, equipo12, puntos12,
            pos13, victorias13, equipo13, puntos13, pos14, victorias14, equipo14, puntos14, pos15, victorias15, equipo15, puntos15, pos16, victorias16, equipo16, puntos16,
            pos17, victorias17, equipo17, puntos17, pos18, victorias18, equipo18, puntos18, pos19, victorias19, equipo19, puntos19;
    public static TextView emp0,emp1,emp2,emp3,emp4,emp5,emp6,emp7,emp8,emp9,emp10,emp11,emp12,emp13,emp14,emp15,emp16,emp17,emp18,emp19,textLiga;
    public static TextView der0,der1,der2,der3,der4,der5,der6,der7,der8,der9,der10,der11,der12,der13,der14,der15,der16,der17,der18,der19;
    public static ImageView imgV0,imgV1,imgV2,imgV3,imgV4,imgV5,imgV6,imgV7,imgV8,imgV9,imgV10,imgV11,imgV12,imgV13,imgV14,imgV15,imgV16,imgV17,imgV18,imgV19;
    public static ArrayList<String> arrayPos = new ArrayList<String>(20);
    public static ArrayList<String> arrayEquipos = new ArrayList<String>(20);
    public static ArrayList<String> arrayVictorias = new ArrayList<String>(20);
    public static ArrayList<String> arrayPuntos = new ArrayList<String>(20);
    public static ArrayList<String> arrayDER = new ArrayList<String>(20);
    public static ArrayList<String> arrayEMP = new ArrayList<String>(20);
    public static ArrayList<String> arrayFLA = new ArrayList<String>(20);

    public Clasificacion() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view =  inflater.inflate(R.layout.clasificacion, container, false);
        findViews(view);
        setHasOptionsMenu(true);
        textLiga.setText("LIGA SANTANDER");
        return view;

    }

    private void findViews(View view) {
        pos0 = view.findViewById(R.id.pos1);
        victorias0 = view.findViewById(R.id.victorias1);
        equipo0 = view.findViewById(R.id.equipo1);
        puntos0 = view.findViewById(R.id.puntos1);
        pos1 = view.findViewById(R.id.pos2);
        victorias1 = view.findViewById(R.id.victorias2);
        equipo1 = view.findViewById(R.id.equipo2);
        puntos1= view.findViewById(R.id.puntos2);
        pos2 = view.findViewById(R.id.pos3);
        victorias2 = view.findViewById(R.id.victorias3);
        equipo2 = view.findViewById(R.id.equipo3);
        puntos2 = view.findViewById(R.id.puntos3);
        pos3 = view.findViewById(R.id.pos4);
        victorias3 = view.findViewById(R.id.victorias4);
        equipo3 = view.findViewById(R.id.equipo4);
        puntos3 = view.findViewById(R.id.puntos4);
        pos4 = view.findViewById(R.id.pos5);
        victorias4 = view.findViewById(R.id.victorias5);
        equipo4 = view.findViewById(R.id.equipo5);
        puntos4 = view.findViewById(R.id.puntos5);
        pos5 = view.findViewById(R.id.pos6);
        victorias5 = view.findViewById(R.id.victorias6);
        equipo5 = view.findViewById(R.id.equipo6);
        puntos5 = view.findViewById(R.id.puntos6);
        pos6 = view.findViewById(R.id.pos7);
        victorias6 = view.findViewById(R.id.victorias7);
        puntos6 = view.findViewById(R.id.puntos7);
        equipo6 = view.findViewById(R.id.equipo7);
        pos8 = view.findViewById(R.id.pos9);
        victorias8 = view.findViewById(R.id.victorias9);
        equipo8 = view.findViewById(R.id.equipo9);
        puntos8 = view.findViewById(R.id.puntos9);
        pos7 = view.findViewById(R.id.pos8);
        victorias7 = view.findViewById(R.id.victorias8);
        equipo7 = view.findViewById(R.id.equipo8);
        puntos7 = view.findViewById(R.id.puntos8);
        pos9 = view.findViewById(R.id.pos10);
        victorias9 = view.findViewById(R.id.victorias10);
        equipo9 = view.findViewById(R.id.equipo10);
        puntos9 = view.findViewById(R.id.puntos10);
        pos10 = view.findViewById(R.id.pos11);
        victorias10 = view.findViewById(R.id.victorias11);
        equipo10 = view.findViewById(R.id.equipo11);
        puntos10 = view.findViewById(R.id.puntos11);
        pos11 = view.findViewById(R.id.pos12);
        victorias11 = view.findViewById(R.id.victorias12);
        equipo11 = view.findViewById(R.id.equipo12);
        puntos11 = view.findViewById(R.id.puntos12);
        pos12 = view.findViewById(R.id.pos13);
        victorias12 = view.findViewById(R.id.victorias13);
        equipo12 = view.findViewById(R.id.equipo13);
        puntos12 = view.findViewById(R.id.puntos13);
        pos13 = view.findViewById(R.id.pos14);
        victorias13 = view.findViewById(R.id.victorias14);
        equipo13 = view.findViewById(R.id.equipo14);
        puntos13 = view.findViewById(R.id.puntos14);
        pos14 = view.findViewById(R.id.pos15);
        victorias14 = view.findViewById(R.id.victorias15);
        equipo14 = view.findViewById(R.id.equipo15);
        puntos14 = view.findViewById(R.id.puntos15);
        pos15 = view.findViewById(R.id.pos16);
        victorias15 = view.findViewById(R.id.victorias16);
        equipo15 = view.findViewById(R.id.equipo16);
        puntos15 = view.findViewById(R.id.puntos16);
        pos16 = view.findViewById(R.id.pos17);
        victorias16 = view.findViewById(R.id.victorias17);
        equipo16 = view.findViewById(R.id.equipo17);
        puntos16 = view.findViewById(R.id.puntos17);
        pos17 = view.findViewById(R.id.pos18);
        victorias17 = view.findViewById(R.id.victorias18);
        equipo17 = view.findViewById(R.id.equipo18);
        puntos17 =view.findViewById(R.id.puntos18);
        pos18 = view.findViewById(R.id.pos19);
        victorias18 = view.findViewById(R.id.victorias19);
        equipo18 = view.findViewById(R.id.equipo19);
        puntos18 = view.findViewById(R.id.puntos19);
        pos19 = view.findViewById(R.id.pos20);
        victorias19 = view.findViewById(R.id.victorias20);
        equipo19 = view.findViewById(R.id.equipo20);
        puntos19 = view.findViewById(R.id.puntos20);


        der0 = view.findViewById(R.id.derrotas1);
        der1 = view.findViewById(R.id.derrotas2);
        der2 = view.findViewById(R.id.derrotas3);
        der3 = view.findViewById(R.id.derrotas4);
        der4 = view.findViewById(R.id.derrotas5);
        der5 = view.findViewById(R.id.derrotas6);
        der6 = view.findViewById(R.id.derrotas7);
        der7 = view.findViewById(R.id.derrotas8);
        der8 = view.findViewById(R.id.derrotas9);
        der9 = view.findViewById(R.id.derrotas10);
        der10 = view.findViewById(R.id.derrotas11);
        der11 = view.findViewById(R.id.derrotas12);
        der12 = view.findViewById(R.id.derrotas13);
        der13 = view.findViewById(R.id.derrotas14);
        der14 = view.findViewById(R.id.derrotas15);
        der15 = view.findViewById(R.id.derrotas16);
        der16 = view.findViewById(R.id.derrotas17);
        der17 = view.findViewById(R.id.derrotas18);
        der18 = view.findViewById(R.id.derrotas19);
        der19 = view.findViewById(R.id.derrotas20);

        emp0 = view.findViewById(R.id.empates1);
        emp1 = view.findViewById(R.id.empates2);
        emp2 = view.findViewById(R.id.empates3);
        emp3 = view.findViewById(R.id.empates4);
        emp4 = view.findViewById(R.id.empates5);
        emp5 = view.findViewById(R.id.empates6);
        emp6 = view.findViewById(R.id.empates7);
        emp7 = view.findViewById(R.id.empates8);
        emp8 = view.findViewById(R.id.empates9);
        emp9 = view.findViewById(R.id.empates10);
        emp10 = view.findViewById(R.id.empates11);
        emp11 = view.findViewById(R.id.empates12);
        emp12 = view.findViewById(R.id.empates13);
        emp13 = view.findViewById(R.id.empates14);
        emp14 = view.findViewById(R.id.empates15);
        emp15 = view.findViewById(R.id.empates16);
        emp16 = view.findViewById(R.id.empates17);
        emp17 = view.findViewById(R.id.empates18);
        emp18 = view.findViewById(R.id.empates19);
        emp19 = view.findViewById(R.id.empates20);

        imgV0 = view.findViewById(R.id.imageView2);
        imgV1 = view.findViewById(R.id.imageView3);
        imgV2 = view.findViewById(R.id.imageView4);
        imgV3 = view.findViewById(R.id.imageView5);
        imgV4 = view.findViewById(R.id.imageView6);
        imgV5 = view.findViewById(R.id.imageView7);
        imgV6 = view.findViewById(R.id.imageView8);
        imgV7 = view.findViewById(R.id.imageView9);
        imgV8 = view.findViewById(R.id.imageView10);
        imgV9 = view.findViewById(R.id.imageView11);
        imgV10 = view.findViewById(R.id.imageView12);
        imgV11 = view.findViewById(R.id.imageView13);
        imgV12 = view.findViewById(R.id.imageView14);
        imgV13 = view.findViewById(R.id.imageView15);
        imgV14 = view.findViewById(R.id.imageView16);
        imgV15 = view.findViewById(R.id.imageView17);
        imgV16 = view.findViewById(R.id.imageView18);
        imgV17 = view.findViewById(R.id.imageView19);
        imgV18 = view.findViewById(R.id.imageView20);
        imgV19 = view.findViewById(R.id.imageView21);

        textLiga = view.findViewById(R.id.textLiga);

    }
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_jornada, menu);
        setHasOptionsMenu(true);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.espa:

                String pelicula = "1";
                new HiloClasificacion(pelicula).execute();
                textLiga.setText("LIGA SANTANDER");


                return true;
            case R.id.premier:
                String pelicul = "10";
                new HiloClasificacion(pelicul).execute();
                textLiga.setText("PREMIER LEAGUE");

                return true;

        }

        return super.onOptionsItemSelected(item);
    }
    public static void datosBien(String mensaje) throws JSONException {

        JSONObject jsonObject = new JSONObject(mensaje);

        JSONArray jsonArray = jsonObject.getJSONArray("table");

        JSONObject json;

        for (int i = 0; i < jsonArray.length(); i++) {

            json = jsonArray.getJSONObject(i);
            arrayEquipos.add(i, json.getString("team"));
            arrayPos.add(i, json.getString("pos"));
            arrayVictorias.add(i, json.getString("wins"));
            arrayPuntos.add(i, json.getString("points"));
            arrayDER.add(i, json.getString("losses"));
            arrayEMP.add(i, json.getString("draws"));
            arrayFLA.add(i,json.getString("shield"));

        }
        pos0.setText(arrayPos.get(0));
        victorias0.setText(arrayVictorias.get(0));
        equipo0.setText(arrayEquipos.get(0));
        puntos0.setText(arrayPuntos.get(0));
        pos1.setText(arrayPos.get(1));
        victorias1.setText(arrayVictorias.get(1));
        equipo1.setText(arrayEquipos.get(1));
        puntos1.setText(arrayPuntos.get(1));
        pos2.setText(arrayPos.get(2));
        victorias2.setText(arrayVictorias.get(2));
        equipo2.setText(arrayEquipos.get(2));
        puntos2.setText(arrayPuntos.get(2));
        pos3.setText(arrayPos.get(3));
        victorias3.setText(arrayVictorias.get(3));
        equipo3.setText(arrayEquipos.get(3));
        puntos3.setText(arrayPuntos.get(3));
        pos4.setText(arrayPos.get(4));
        victorias4.setText(arrayVictorias.get(4));
        equipo4.setText(arrayEquipos.get(4));
        puntos4.setText(arrayPuntos.get(4));
        pos5.setText(arrayPos.get(5));
        victorias5.setText(arrayVictorias.get(5));
        equipo5.setText(arrayEquipos.get(5));
        puntos5.setText(arrayPuntos.get(5));
        pos6.setText(arrayPos.get(6));
        victorias6.setText(arrayVictorias.get(6));
        equipo6.setText(arrayEquipos.get(6));
        puntos6.setText(arrayPuntos.get(6));
        pos7.setText(arrayPos.get(7));
        victorias7.setText(arrayVictorias.get(7));
        equipo7.setText(arrayEquipos.get(7));
        puntos7.setText(arrayPuntos.get(7));
        pos8.setText(arrayPos.get(8));
        victorias8.setText(arrayVictorias.get(8));
        equipo8.setText(arrayEquipos.get(8));
        puntos8.setText(arrayPuntos.get(8));
        pos9.setText(arrayPos.get(9));
        victorias9.setText(arrayVictorias.get(9));
        equipo9.setText(arrayEquipos.get(9));
        puntos9.setText(arrayPuntos.get(9));
        pos10.setText(arrayPos.get(10));
        victorias10.setText(arrayVictorias.get(10));
        equipo10.setText(arrayEquipos.get(10));
        puntos10.setText(arrayPuntos.get(10));
        pos11.setText(arrayPos.get(11));
        victorias11.setText(arrayVictorias.get(11));
        equipo11.setText(arrayEquipos.get(11));
        puntos11.setText(arrayPuntos.get(11));
        pos12.setText(arrayPos.get(12));
        victorias12.setText(arrayVictorias.get(12));
        equipo12.setText(arrayEquipos.get(12));
        puntos12.setText(arrayPuntos.get(12));
        pos13.setText(arrayPos.get(13));
        victorias13.setText(arrayVictorias.get(13));
        equipo13.setText(arrayEquipos.get(13));
        puntos13.setText(arrayPuntos.get(13));
        pos14.setText(arrayPos.get(14));
        victorias14.setText(arrayVictorias.get(14));
        equipo14.setText(arrayEquipos.get(14));
        puntos14.setText(arrayPuntos.get(14));
        pos15.setText(arrayPos.get(15));
        victorias15.setText(arrayVictorias.get(15));
        equipo15.setText(arrayEquipos.get(15));
        puntos15.setText(arrayPuntos.get(15));
        pos16.setText(arrayPos.get(16));
        victorias16.setText(arrayVictorias.get(16));
        equipo16.setText(arrayEquipos.get(16));
        puntos16.setText(arrayPuntos.get(16));

        pos17.setText(arrayPos.get(17));
        victorias17.setText(arrayVictorias.get(17));
        equipo17.setText(arrayEquipos.get(17));
        puntos17.setText(arrayPuntos.get(17));

        pos18.setText(arrayPos.get(18));
        victorias18.setText(arrayVictorias.get(18));
        equipo18.setText(arrayEquipos.get(18));
        puntos18.setText(arrayPuntos.get(18));

        pos19.setText(arrayPos.get(19));
        victorias19.setText(arrayVictorias.get(19));
        equipo19.setText(arrayEquipos.get(19));
        puntos19.setText(arrayPuntos.get(19));


        emp0.setText(arrayEMP.get(0));
        emp1.setText(arrayEMP.get(1));
        emp2.setText(arrayEMP.get(2));
        emp3.setText(arrayEMP.get(3));
        emp4.setText(arrayEMP.get(4));
        emp5.setText(arrayEMP.get(5));
        emp6.setText(arrayEMP.get(6));
        emp7.setText(arrayEMP.get(7));
        emp8.setText(arrayEMP.get(8));
        emp9.setText(arrayEMP.get(9));
        emp10.setText(arrayEMP.get(10));
        emp11.setText(arrayEMP.get(11));
        emp12.setText(arrayEMP.get(12));
        emp13.setText(arrayEMP.get(13));
        emp14.setText(arrayEMP.get(14));
        emp15.setText(arrayEMP.get(15));
        emp16.setText(arrayEMP.get(16));
        emp17.setText(arrayEMP.get(17));
        emp18.setText(arrayEMP.get(18));
        emp19.setText(arrayEMP.get(19));

        der0.setText(arrayDER.get(0));
        der1.setText(arrayDER.get(1));
        der2.setText(arrayDER.get(2));
        der3.setText(arrayDER.get(3));
        der4.setText(arrayDER.get(4));
        der5.setText(arrayDER.get(5));
        der6.setText(arrayDER.get(6));
        der7.setText(arrayDER.get(7));
        der8.setText(arrayDER.get(8));
        der9.setText(arrayDER.get(9));
        der10.setText(arrayDER.get(10));
        der11.setText(arrayDER.get(11));
        der12.setText(arrayDER.get(12));
        der13.setText(arrayDER.get(13));
        der14.setText(arrayDER.get(14));
        der15.setText(arrayDER.get(15));
        der16.setText(arrayDER.get(16));
        der17.setText(arrayDER.get(17));
        der18.setText(arrayDER.get(18));
        der19.setText(arrayDER.get(19));


        Picasso.get().load(arrayFLA.get(0)).into(imgV0);
        Picasso.get().load(arrayFLA.get(1)).into(imgV1);
        Picasso.get().load(arrayFLA.get(2)).into(imgV2);
        Picasso.get().load(arrayFLA.get(3)).into(imgV3);
        Picasso.get().load(arrayFLA.get(4)).into(imgV4);
        Picasso.get().load(arrayFLA.get(5)).into(imgV5);
        Picasso.get().load(arrayFLA.get(6)).into(imgV6);
        Picasso.get().load(arrayFLA.get(7)).into(imgV7);
        Picasso.get().load(arrayFLA.get(8)).into(imgV8);
        Picasso.get().load(arrayFLA.get(9)).into(imgV9);
        Picasso.get().load(arrayFLA.get(10)).into(imgV10);
        Picasso.get().load(arrayFLA.get(11)).into(imgV11);
        Picasso.get().load(arrayFLA.get(12)).into(imgV12);
        Picasso.get().load(arrayFLA.get(13)).into(imgV13);
        Picasso.get().load(arrayFLA.get(14)).into(imgV14);
        Picasso.get().load(arrayFLA.get(15)).into(imgV15);
        Picasso.get().load(arrayFLA.get(16)).into(imgV16);
        Picasso.get().load(arrayFLA.get(17)).into(imgV17);
        Picasso.get().load(arrayFLA.get(18)).into(imgV18);
        Picasso.get().load(arrayFLA.get(19)).into(imgV19);
        //Picasso.get().load(arrayFLA.get(20)).into(imgV19);

    }
}
