package com.example.game70;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import com.example.game70.hilo.HiloCalendario;
import com.example.game70.hilo.HiloClasificacion;
import com.example.game70.hilo.HiloResultados;
import com.example.game70.navegacion.Calendario;
import com.example.game70.navegacion.Clasificacion;
import com.example.game70.navegacion.Noticias;
import com.example.game70.navegacion.Resultados;


public class MainActivity extends AppCompatActivity {

    private ActionBar toolbar;
    public Fragment calendario = new Calendario();
    public Fragment noticias = new Noticias();
    public Fragment clasificacion = new Clasificacion();
    public Fragment resul = new Resultados();
    public boolean clas = true;
    public boolean not = false;
    public boolean calen = false;
    public boolean result = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = getSupportActionBar();

        BottomNavigationView navigation = findViewById(R.id.navigationView);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        toolbar.setTitle("Clasificación");
        new HiloClasificacion("1").execute();
        loadFragmentNormal(new Clasificacion());

    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.uno:
                    if (clas == true) {

                    } else {
                        toolbar.setTitle("Clasificación");
                        new HiloClasificacion("1").execute();
                        loadFragmentAtr(new Clasificacion());
                        clas = true;
                        not = false;
                        calen = false;
                        result = false;
                    }
                    return true;
                case R.id.dos:
                    if(not == true) {

                    }else if(clas == true) {
                        toolbar.setTitle("Noticias");
                        loadFragment(new Noticias());

                        clas = false;
                        not = true;
                        calen = false;
                        result = false;
                    }else{
                        toolbar.setTitle("Noticias");
                        loadFragmentAtr(new Noticias());
                        clas = false;
                        not = true;
                        calen = false;
                        result = false;
                    }
                    return true;
                case R.id.tres:

                    if(result == true) {

                    }else if(clas == true || not == true) {
                        new HiloResultados(0, 1).execute();
                        toolbar.setTitle("Resultados");
                        loadFragment(new Resultados());
                        clas = false;
                        not = false;
                        calen = false;
                        result = true;
                    }else {
                        new HiloResultados(0, 1).execute();
                        toolbar.setTitle("Resultados");
                        loadFragmentAtr(new Resultados());
                        clas = false;
                        not = false;
                        calen = false;
                        result = true;
                    }
                    return true;
                case R.id.cautro:
                    if(calen == true) {

                    }else {
                        new HiloCalendario(0, 1).execute();
                        toolbar.setTitle("Calendario");
                        loadFragment(new Calendario());
                        clas = false;
                        not = false;
                        calen = true;
                        result = false;
                    }

                    return true;
            }
            return false;
        }
    };


    private void loadFragmentAtr(Fragment fragment) {
        // load fragment
        android.support.v4.app.FragmentTransaction transaction  = getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(
                        R.animator.animacion_derecha_in,
                        R.animator.animacion_derecha_out);
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
    private void loadFragment(Fragment fragment) {
        // load fragment
        android.support.v4.app.FragmentTransaction transaction  = getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(
                        R.animator.animacion_izquierda_in,
                        R.animator.animacion_izquierda_out);
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
    private void loadFragmentNormal(Fragment fragment) {
        // load fragment
        android.support.v4.app.FragmentTransaction transaction  = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}