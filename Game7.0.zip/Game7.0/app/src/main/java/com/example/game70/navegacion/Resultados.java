package com.example.game70.navegacion;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.game70.hilo.HiloResultados;
import com.example.game70.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class Resultados extends Fragment {

    public static TextView loc0,vis0,fech0,res0,loc1,vis1,fech1,res1,loc2, vis2, fech2, res2, loc3, vis3, fech3, res3,
            loc4, vis4, fech4, res4, loc5, vis5, fech5, res5, loc6, vis6, fech6, res6,
            loc7, vis7, fech7, res7, loc8, vis8, fech8, res8, loc9, vis9, fech9, res9;
    public static int ronda;
    public static TextView jornada, ligaText;
    public static String rondaS, jornadaS;
    public static int jornadaActual, ligaActual, contador = 0;
    public static ImageView jornadaRes, jornadaSum;

    public static ArrayList<String> arrayLoc = new ArrayList<String>(10);
    public static ArrayList<String> arrayVis = new ArrayList<String>(10);
    public static ArrayList<String> arrayFech = new ArrayList<String>(10);
    public static ArrayList<String> arrayRes = new ArrayList<String>(10);
    public static ArrayList<String> arrayJOR = new ArrayList<String>(10);
    public static ArrayList<String> arrayLig = new ArrayList<String>(10);

    public Resultados() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.resultados, container, false);
        findViews(view);
        setHasOptionsMenu(true);
        ligaText.setText("LIGA SANTANDER");
        view.findViewById(R.id.jornadaSum).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ronda == jornadaActual) {
                    Toast.makeText (getActivity (), "Ya estás en la jornada actual", Toast.LENGTH_SHORT ).show ();
                } else {
                    ronda++;
                    rondaS = String.valueOf(ronda);
                    jornada.setText("JORNADA: " + rondaS);
                    new HiloResultados(ronda, ligaActual).execute();
                }

            }
        });

        view.findViewById(R.id.JornadaRes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ronda == 1) {

                    Toast.makeText (getActivity (), "Ya estás en la primera jornada", Toast.LENGTH_SHORT ).show ();
                } else {

                    ronda--;
                    rondaS = String.valueOf(ronda);
                    jornada.setText("JORNADA: " + rondaS);

                    new HiloResultados(ronda, ligaActual).execute();

                }
            }
        });

        return view;

    }

    private void findViews(View view) {
        loc0 = view.findViewById(R.id.pos1);
        vis0 = view.findViewById(R.id.equipo1);
        fech0 = view.findViewById(R.id.victorias1);
        res0 = view.findViewById(R.id.puntos1);
        loc1 = view.findViewById(R.id.pos2);
        vis1 = view.findViewById(R.id.equipo2);
        fech1 = view.findViewById(R.id.victorias2);
        res1 = view.findViewById(R.id.puntos2);
        loc2 = view.findViewById(R.id.pos3);
        vis2 = view.findViewById(R.id.equipo3);
        fech2 = view.findViewById(R.id.victorias3);
        res2 = view.findViewById(R.id.puntos3);
        loc3 = view.findViewById(R.id.pos4);
        vis3 = view.findViewById(R.id.equipo4);
        fech3 = view.findViewById(R.id.victorias4);
        res3 = view.findViewById(R.id.puntos4);
        loc4 = view.findViewById(R.id.pos5);
        vis4 = view.findViewById(R.id.equipo5);
        fech4 = view.findViewById(R.id.victorias5);
        res4 = view.findViewById(R.id.puntos5);
        loc5 = view.findViewById(R.id.pos6);
        vis5 = view.findViewById(R.id.equipo6);
        fech5 = view.findViewById(R.id.victorias6);
        res5 = view.findViewById(R.id.puntos6);
        loc6 = view.findViewById(R.id.pos7);
        vis6 = view.findViewById(R.id.equipo7);
        fech6 = view.findViewById(R.id.victorias7);
        res6 = view.findViewById(R.id.puntos7);
        loc7 = view.findViewById(R.id.pos8);
        vis7 = view.findViewById(R.id.equipo8);
        fech7 = view.findViewById(R.id.victorias8);
        res7 = view.findViewById(R.id.puntos8);
        loc8 = view.findViewById(R.id.pos9);
        vis8 = view.findViewById(R.id.equipo9);
        fech8 = view.findViewById(R.id.victorias9);
        res8 = view.findViewById(R.id.puntos9);
        loc9 = view.findViewById(R.id.pos10);
        vis9 = view.findViewById(R.id.equipo10);
        fech9 = view.findViewById(R.id.victorias10);
        res9 = view.findViewById(R.id.puntos10);
        jornada = view.findViewById(R.id.jornada);
        jornadaRes = view.findViewById(R.id.JornadaRes);
        jornadaSum = view.findViewById(R.id.jornadaSum);
        ligaText = view.findViewById(R.id.textLiga);

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_jornada, menu);
        setHasOptionsMenu(true);
        super.onCreateOptionsMenu(menu, inflater);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.espa:

                new HiloResultados(ronda,1).execute();
                ligaText.setText("LIGA SANTANDER");
                return true;
            case R.id.premier:
                new HiloResultados(ronda,10).execute();
                ligaText.setText("PREMIER LEAGUE");

                return true;

        }

        return super.onOptionsItemSelected(item);
    }

    public static void datosBien(String mensaje) throws JSONException {

        JSONObject jsonObject = new JSONObject(mensaje);

        JSONArray jsonArray = jsonObject.getJSONArray("match");

        JSONObject json;


        if(contador == 0) {

            for (int i = 0; i < jsonArray.length(); i++) {

                json = jsonArray.getJSONObject(i);
                arrayLoc.add(i, json.getString("local"));
                arrayVis.add(i, json.getString("visitor"));
                arrayFech.add(i, json.getString("schedule"));
                arrayRes.add(i, json.getString("result"));
                arrayJOR.add(i, json.getString("round"));
                arrayLig.add(i, json.getString("group"));
                jornadaS = json.getString("round");
                contador++;
            }
        }   else{
            for (int j = 0; j < jsonArray.length(); j++) {

                json = jsonArray.getJSONObject(j);
                arrayLoc.add(j, json.getString("local"));
                arrayVis.add(j, json.getString("visitor"));
                arrayFech.add(j, json.getString("schedule"));
                arrayRes.add(j, json.getString("result"));
                jornadaS = json.getString("round");
            }
        }

        ligaActual = Integer.parseInt(arrayLig.get(0));
        jornadaActual = Integer.parseInt(arrayJOR.get(0));
        ronda =  Integer.parseInt(jornadaS);

        jornada.setText("JORNADA: "+ronda);

        loc0.setText(arrayLoc.get(0));
        vis0.setText(arrayVis.get(0));
        fech0.setText(arrayFech.get(0));
        res0.setText(arrayRes.get(0));
        loc1.setText(arrayLoc.get(1));
        vis1.setText(arrayVis.get(1));
        fech1.setText(arrayFech.get(1));
        res1.setText(arrayRes.get(1));
        loc2.setText(arrayLoc.get(2));
        vis2.setText(arrayVis.get(2));
        fech2.setText(arrayFech.get(2));
        res2.setText(arrayRes.get(2));
        loc3.setText(arrayLoc.get(3));
        vis3.setText(arrayVis.get(3));
        fech3.setText(arrayFech.get(3));
        res3.setText(arrayRes.get(3));
        loc4.setText(arrayLoc.get(4));
        vis4.setText(arrayVis.get(4));
        fech4.setText(arrayFech.get(4));
        res4.setText(arrayRes.get(4));
        loc5.setText(arrayLoc.get(5));
        vis5.setText(arrayVis.get(5));
        fech5.setText(arrayFech.get(5));
        res5.setText(arrayRes.get(5));
        loc6.setText(arrayLoc.get(6));
        vis6.setText(arrayVis.get(6));
        fech6.setText(arrayFech.get(6));
        res6.setText(arrayRes.get(6));
        loc7.setText(arrayLoc.get(7));
        vis7.setText(arrayVis.get(7));
        fech7.setText(arrayFech.get(7));
        res7.setText(arrayRes.get(7));
        loc8.setText(arrayLoc.get(8));
        vis8.setText(arrayVis.get(8));
        fech8.setText(arrayFech.get(8));
        res8.setText(arrayRes.get(8));
        loc9.setText(arrayLoc.get(9));
        vis9.setText(arrayVis.get(9));
        fech9.setText(arrayFech.get(9));
        res9.setText(arrayRes.get(9));

    }

}