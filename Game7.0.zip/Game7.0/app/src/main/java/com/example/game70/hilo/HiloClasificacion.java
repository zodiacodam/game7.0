package com.example.game70.hilo;

import android.os.AsyncTask;

import com.example.game70.navegacion.Clasificacion;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class HiloClasificacion extends AsyncTask<Void, Void, Void> {

    private String ronda, mensaje = "";
    private static String key = "7d6d48f72c081257ff93dce53712e860";

    public HiloClasificacion(String ronda) {
        this.ronda = ronda;

    }

    @Override
    protected Void doInBackground(Void... voids) {

        try {
            mensaje = recogerDatos();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;

    }

    private String recogerDatos() throws IOException {

        URL urlws = new URL("https://apiclient.besoccerapps.com/scripts/api/api.php?key=" + key + "&tz=Europe/Madrid&format=json&req=tables&league=" + ronda + "&group=1");
        URLConnection uc = urlws.openConnection();
        uc.connect();
        BufferedReader in = new BufferedReader(new InputStreamReader(uc.getInputStream()));
        String inputLine = "";
        String contenido = "";

        while((inputLine = in.readLine()) != null) {
            contenido += inputLine + "\n";
        }

        in.close();
        return contenido;

    }

    protected void onPostExecute(Void aVoid) {

        super.onPostExecute(aVoid);
        try {
            Clasificacion.datosBien(mensaje);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

}